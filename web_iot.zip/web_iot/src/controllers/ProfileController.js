
const ProfileController = {
    getProfile: async(req, res) => { res.render("profile"); }
}
module.exports = ProfileController;

  